from pygame import *
import math
from random import choice
from pygame import transform
from pygame import sprite
from pygame import time

class Blocker(sprite.Sprite):
    def __init__(self, size, color, row, column):
        sprite.Sprite.__init__(self)
        self.height = size
        self.width = size
        self.color = color
        self.image = Surface((self.width, self.height))
        self.image.fill(self.color)
        self.rect = self.image.get_rect()
        self.row = row
        self.column = column

    def update(self, screen, keys):
        screen.blit(self.image, self.rect)

# レーザー
class Laser(sprite.Sprite):
    def __init__(self, xpos, ypos, direction, speed, image):
        sprite.Sprite.__init__(self)
        self.image = transform.rotate(image, direction)
        self.rect = self.image.get_rect(topleft=(xpos, ypos))
        self.speed = speed
        self.direction = direction

    def update(self, screen, keys):
        screen.blit(self.image, seli.rect)
        radian = math.radians(self.direction)
        self.rect.x += self.speed * math.sin(radian)
        self.rect.y += self.speed * math.cos(radian)
        if self.rect.x < 10 or self.rect.x > 790 or self.rect.y < 15 or self.rect.y > 600:
            self.kill()

# 敵機
class Enemy(sprite.Sprite):
    def __init__(self, row, column, img):
        sprite.Sprite.__init__(self)
        self.row = row
        self.column = column
        self.image = transform.scale(img, (55, 35))
        self.rect = self.image.get_rect()

    def update(self, screen, keys):
        screen.blit(self.image, self.rect)


class EnemiesGroup(sprite.Group):
        sprite.Group.__init__(self)
        self.ENEMY_MOVE_DOWN = 35

        self.enemies = [[None] * columns for _ in range(rows)]
        self.columns = columns
        self.rows = rows
        self.leftAddMove = 0
        self.rightAddMove = 0
        self.moveTime = 600
        self.direction = 1
        self.rightMoves = 30
        self.leftMoves = 30
        self.moveNumber = 15
        self.timer = time.get_ticks()
        self.bottom = 65 + ((rows - 1) * 45) + 35
        self._aliveColumns = list(range(columns))
        self._leftAliveColumn = 0
        self._rightAliveColumn = 0
        self.enemy_image = image
        self.make_enemies()

    def make_enemies(self):
        for row in range(self.rows):
            enemy = Enemy(row, column, self.enemy_image)
            enemy.rect.x = 150 + (column * 50)
            enemy.rect.y = 65 + (row * 45)
            self.add(enemy)

    def update(self, screen, keys):
        past = time.get_ticks()
        if past - self.timer > self.moveTime:
            if self.direction == 1:
                max_move = self.rightMoves + self.rightAddMove
            else:
                max_move = self.leftMoves + self.rightAddMove

            if self.moveNumber >= max_move:
                self.leftMoves = 30 + self.rightAddMove
                self.rightMoves = 30 + self.leftAddMove
                self.direction *= -1
                self.moveNumber = 0
                self.bottom = 0
                for enemy in self:
                    enemy.rect.y += self.ENEMY_MOVE_DOWN
                    if self.bottom < enemy.rect.y + 35:
                        self.bottom = enemy.rect.y + 35

                    else:
                        velocity = 10 if self.direction == 1 else -10
                        for enemy in self:
                            enemy.rect.x += velocity
                        self.moveNumber += 1

                    self.timer = past
                super(EnemiesGroup, self).update(screen, keys)

            def add_internal(self, *sprites):
                super(EnemiesGroup, self).add_internal(*sprites)
                for s in sprites:
                    self.enemies[s.row][s.columns] = s

            def remove_internal(self, *sprites):
                super(EnemiesGroup, self).remove_internal(*sprites)
                for s in sprites:
                    self.kill(s)

            def is_column_dead(self, column):
                return not any(self.enemies[row][column]
                                for row in range(self.rows))
            
            def random_bottom(self) -> Enemy:
                col = choice(self._aliveColumns)
                col_enemies = (self.enemies[row -1][col]
                                for row in range(self.rows, 0, -1))
                return next((en for en in col_enemies if en is not None), None)
            
            def kill(self, enemy):
                self.enemies[enemy.row][enemy.column] = None
                is_column_dead = self.is_column_dead(enemy.column)

                if is_column_dead:
                    self._aliveColumns.remove(enemy.column)

                if enemy.column == self._rightAliveColumn:
                    while self._rightAliveColumn > 0 and is_column_dead:
                        self._rightAliveColumn -= 1
                        self.rightAddMove += 5
                        is_column_dead = self.is_column_dead(self._rightAliveColumn)

                elif enemy.column == self._leftAliveColumn:
                    while self._leftAliveColumn < self.columns and is_column_dead:
                        self._leftAliveColumn += 1
                        self.leftAddMove += 5
                        is_column_dead = self.is_column_dead(self._leftAliveColumn)

# 残機
class Life(sprite.Sprite):
    def __init__(self, xpos, ypos, img):
        sprite.Sprite.__init__(self)
        self.image = transform.scale(img, (23, 27))
        self.rect = self.image.get_rect(topleft = (xpos, ypos))

    def update(self, screen, keys):
        screen.blit(self.image, self.rect)