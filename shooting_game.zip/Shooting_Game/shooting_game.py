from pygame import *
import sys
from os.path import abspath, dirname
import random
import math
from enum import Enum
from game_lib import game_object
from mutagen.mp3 import MP3

from pygame import transform
from pygame import sprite
from pygame import time
from pygame import mixer
from pygame import display
from pygame import event
from pygame import key

# ファイルへのパス
BASE_PATH = abspath(dirname(__file__))
FONT_PATH = BASE_PATH + '/fonts/'
IMAGE_PATH = BASE_PATH + '/images/'
SOUND_PATH = BASE_PATH + '/sounds/'

# 色 R G B
WHITE = (255, 255, 255)
GREEN = (78, 255, 87)
#スクリーンサイズ
SCREEN = display.set_mode((800, 600), flags=NOFRAME)

# ブロックのY軸、敵機ポジション初期値
BLOCKERS_POSITION = 450
ENEMY_DEFAULT_POSITION = 65

# スクリーン名
class GameScreen(Enum):
    StartMenu = 1
    Playing = 2

# フォントと画像ファイルの読み込み
FONT = FONT_PATH + 'ShootingGame.ttf'
IMG_NAMES = ['ship', 'enemy', 'laser', 'enemylaser']
IMAGES = {name: image.load(IMAGE_PATH + '{},png'.format(name)).convert_alpha() for name in IMG_NAMES}

# ship定義
class Ship(sprite.Sprite):
    def __init__(self, img):
        sprite.Sprite.__init__(self)
        self.image = transform.scale(img, (50, 50))
        self.rect = self.image.get_rect(topleft=(375, 540))
        self.speed = 5

    def update(self, screen, keys):
        if keys[K_LEFT] and self.rect.x > 0:
            self.rect.x = self.rect.x - self.speed
        if keys[K_RIGHT] and self.rect.x < 750:
            self.rect.x = self.rect.x + self.speed
        if keys[K_UP] and self.rect.y > 0:
            self.rect.y = self.rect.y - self.speed
        if keys[K_DOWN] and self.rect.x < 550:
            self.rect.y = self.rect.y - self.speed
        screen.blit(self.image, self.rect)

class SpaceShooting(object):
    # mainループ
    def main(self):
        while True:
            if self.currentScreen == GameScreen.StartMenu:
                self.create_start_menu()
                for e in event.get():
                    if e.type == KEYDOWN and e.key == K_RETURN:
                        self.currentScreen = GameScreen.Playing
                        self.reset()
                    elif e.type == KEYDOWN and e.key == K_ESCAPE:
                        sys.exit()

            elif self.currentScreen == GameScreen.Playing:
                self.screen.blit(self.background, (0, 0))
                self.check_input()
                if self.random_judge(4) == True:
                    self.make_enemies_shoot()
                self.check_collisions()
                self.keys = key.get_pressed()
                self.enemies.update(self.screen, self.keys)
                self.allSprites.update(self.screen, self.keys)

            display.update()
            self.clock.tick(50)

    #初期設定
    def reset(self):
        self.allSprites = sprite.Group()
        self.playerGroup = sprite.Group()
        self.shipLasers = sprite.Group()
        self.enemies = game_object.EnemiesGroup(10, 3, IMAGES['enemy'])
        self.enemyLasers = sprite.Group()
        self.blockers = sprite.Group()
        self.blockers.add(self.make_blockers(0), self.make_blockers(1), self.make_blockers(2), self.make_blockers(3))
        self.life1 = game_object.Life(740, 0, IMAGES['ship'])
        self.life2 = game_object.Life(770, 0, IMAGES['ship'])
        self.life3 = game_object.Life(800, 0, IMAGES['ship'])
        self.allSprites.add(self.life1, self.life2, self.life3)
        self.allSprites.add(self.blockers)
        self.create_new_ship()
        self.create_audio()
        self.play_music('backmusic', 0.4)

    # キー入力処理
    def check_input(self):
        for e in event.get():
            if e.type == KEYDOWN and e.key == K_ESCAPE:
                sys.exit()

            if e.type == KEYDOWN and e.key == K_SPACE:
                self.laser = game_object.Laser(self.player.rect.x + 25, self.player.rect.y, 180, 10, IMAGES['laser'])
                self.allSprites.add(self.laser)
                self.shipLasers.add(self.laser)
                self.sounds['shoot'].play()

    # 宇宙船作成
    def create_new_ship(self):
        self.player = Ship(IMAGES['ship'])
        self.allSprites.add(self.player)
        self.playerGroup.add(self.player)

    #衝突判定
    def check_collisions(self):
        for s in sprite.groupcollide(self.shipLasers, self.blockers, True, True).keys():
            self.sounds['blockbreak'].play()
        for s in sprite.groupcollide(self.shipLasers, self.enemies, True, True).keys():
            self.sounds['enemykilled'].play()
            if len(self.enemies) == 0:
                self.create_game_clear()
        for s in sprite.groupcollide(self.enemyLasers, self.blockers, True, True).keys():
            self.sounds['blockbreak'].play()
        for s in sprite.groupcollide(self.enemyLasers, self.playerGroup, True, True).keys():
            self.sounds['shipbreak'].play()
            if self.life1.alive() == True:
                self.life1.kill()
                self.create_new_ship()
            elif self.life2.alive() == True:
                self.life2.kill()
                self.create_new_ship()
            elif self.life3.alive() == True:
                self.life3.kill()
                self.create_game_over()

    # 敵機レーザー生成
    def make_enemies_shoot(self):
        self.choice_enemy = self.enemies.random_bottom()
        self.enemy_Laser = game_object.Laser(self.choice_enemy.rect.x + 25, self.choice_enemy.rect.y, 0, 10, IMAGES['enemylaser'])
        self.allSprites.add(self.enemy_Laser)
        self.enemyLasers.add(self.enemy_Laser)

    #ランダムにTrue値を返す
    def random_judge(self, rate):
        rand = random.randint(1, 1000)
        return rand <= rate * 10 

    #ゲームオーバー画面生成
    def create_game_over(self):
        self.screen.blit(self.background, (0, 0))
        titleText = Text(FONT, 50, 'Game Over', WHITE, 250, 300)
        titleText.draw(self.screen)
        display.update()
        self.play_music('gameover', 1, loop = False) 
        time.delay(5000)
        self.currentScreen = GameScreen.StartMenu

    # ゲームクリア画面生成
    def create_game_clear(self):
        self.screen.blit(self.background, (0, 0))
        titleText = Text(FONT, 50, 'Game Clear', WHITE, 250, 300)
        titleText.draw(self.screen)
        display.update()
        self.play_music('gameclear', 1, loop = False)
        time.delay(5000)
        self.currentScreen = GameScreen.StartMenu    

    # スタート画面生成
    def create_start_menu(self):
        self.screen.blit(self.background, (0, 0))
        titleText = Text(FONT, 50, 'Space Shooting', WHITE, 164, 155)
        titleText.draw(self.screen)
        titleText2 = Text(FONT, 25, 'Press Enter to continue', WHITE, 201, 250)
        titleText2.draw(self.screen)
        self.screen.blit(transform.scale(IMAGES['enemy'], (55, 40)), (300, 370))
        self.screen.blit(transform.scale(IMAGES['enemy'], (55, 40)), (370, 370))
        self.screen.blit(transform.scale(IMAGES['enemy'], (55, 40)), (440, 370))
        display.update()

    #コンストラクタ定義
    def __init__(self):
        mixer.pre_init(44100, -16, 1, 4096)
        init()
        self.clock = time.Clock()
        self.caption = display.set_caption('Space Shooting')
        self.screen = SCREEN
        self.background = image.load(IMAGE_PATH + 'background.jpg').convert()
        self.currentScreen = GameScreen.StartMenu

    # ブロックの生成
    def make_blockes(self, number):
        blockerGroup = sprite.Group()
        for row in range(4)
            for column in range(9):
                blocker = game_object.Blocker(10, GREEN, row, column)
                blocker.rect.x = 50 + (200 * number) + (column * blocker.width)
                blocker.rect.y = BLOCKERS_POSITION + (row * blocker.height)
                blockerGroup.add(blocker)
        return blockerGroup
    
    #効果音ファイルの読み込み
    def create_audio(self):
        self.sounds = {}
        for sound_name in ['shoot', 'enemykilled', 'shipbreak', 'blockbreak']:
            self.sounds[sound_name] = mixer.Sound(
                SOUND_PATH + '{}.mp3'.format(sound_name))
            self.sounds[sound_name].set_volume(0, 2)

    # BGMの再生
    def play_music(self, filename, volume = 1, loop = True):
        mixer.music.unload()
        mixer.music.load(SOUND_PATH + filename + 'mp3')
        mixer.music.set_volume(volume)
        mixer.music.play(-1 if loop == True else 1)
        if (not loop):
            audio = MP3(SOUND_PATH + filename + 'mp3')
            time.delay(int(audio.info.length))

    # テキストクラスの定義
    class Text(object):
        def __init__(self, textFont, size, message, color, xpos, ypos):
            self.font = font.Font(textFont, size)
            self.surface = self.font.render(message, True, color)
            self.rect = self.surface.get_rect(topleft = (xpos, ypos))

        def draw(self, surface):
            surface.blit(self.surface, self.rect)

    game = SpaceShooting()
    game.main()